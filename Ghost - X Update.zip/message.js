require('./config')
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const chalk = require("chalk");
const fetch = require('node-fetch')
const axios = require('axios')
const cheerio = require('cheerio')
const { performance } = require("perf_hooks");
const process = require('process');
const moment = require("moment-timezone")
const os = require('os');
const yts = require("yt-search");
const ytdl = require('@vreden/youtube_scraper');
const checkDiskSpace = require('check-disk-space').default;
const speed = require('performance-now')
const sharp = require('sharp');
const Tesseract = require('tesseract.js');
const path = require('path')
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const { 
       remini,
       igdl,
       mediafire, 
       tiktok
       } = require('./lib/scraper');
const { 
       bytesToSize,
       checkBandwidth, 
       formatSize, 
       tanggal,
       getBuffer, 
       isUrl, 
       sleep,
       fetchJson, 
       jsonformat, 
       nganuin, 
       pickRandom, 
       runtime, 
       shorturl, 
       formatp, 
       color, 
       getGroupAdmins
       } = require("./lib/myfunc");
const { 
       addExif
       } = require('./lib/exif')


module.exports = GhostXz = async (GhostXz, m, chatUpdate, store) => {
try {
const body = (m && m?.mtype) ? (
m?.mtype === 'conversation' ? m?.message?.conversation :
m?.mtype === 'imageMessage' ? m?.message?.imageMessage?.caption :
m?.mtype === 'videoMessage' ? m?.message?.videoMessage?.caption :
m?.mtype === 'extendedTextMessage' ? m?.message?.extendedTextMessage?.text :
m?.mtype === 'buttonsResponseMessage' ? m?.message?.buttonsResponseMessage?.selectedButtonId :
m?.mtype === 'listResponseMessage' ? m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m?.mtype === 'templateButtonReplyMessage' ? m?.message?.templateButtonReplyMessage?.selectedId :
m?.mtype === 'messageContextInfo' ? (
m?.message?.buttonsResponseMessage?.selectedButtonId || 
m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
m?.text
) : ''
) : '';

const budy = (m && typeof m?.text === 'string') ? m?.text : '';
const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!`™©®Δ^βα~¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1);
const full_args = body.replace(command, '').slice(1).trim();
const pushname = m?.pushName || "No Name";
const botNumber = await GhostXz.decodeJid(GhostXz.user.id);
const isCreator = [GhostXz.decodeJid(GhostXz.user.id), ...global.rowner.map(([number]) => number), ].map((v) => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const itsMe = (m && m?.sender && m?.sender == botNumber) || false;
const text = q = args.join(" ");
const fatkuns = m && (m?.quoted || m);
const quoted = (fatkuns?.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] :
(fatkuns?.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
(fatkuns?.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] :
m?.quoted || m;
const mime = ((quoted?.msg || quoted) || {}).mimetype || '';
const qmsg = (quoted?.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

//group
const groupMetadata = m?.isGroup ? await GhostXz.groupMetadata(m?.chat).catch(e => {}) : {};
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const participants = m?.isGroup ? await groupMetadata.participants || [] : [];
const groupAdmins = m?.isGroup ? await getGroupAdmins(participants) || [] : [];
const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m?.isGroup ? groupAdmins.includes(m?.sender) : false;
const groupOwner = m?.isGroup ? groupMetadata.owner || '' : '';
const isGroupOwner = m?.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m?.sender) : false;

//================== [ TIME ] ==================//
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ'
        }
        
//Quoted
const qtext = {
  key: {
    remoteJid: "status@broadcast",
    participant: "0@s.whatsapp.net"
  },
  message: {
    extendedTextMessage: {
      text: `${prefix + command}`
    }
  }
};

const fake = {
key: {
participant: '0@s.whatsapp.net',
remoteJid: "0@s.whatsapp.net"
},
message: {
extendedTextMessage: {
text: `Ghost - X`,
title: "powered",
thumbnailUrl: 'https://files.catbox.moe/6pausp.jpg'
}
}
}

    if (budy.includes("@everyone")) {
    if (m.isGroup) {
        if (isCreator || isBotAdmins) {
            return GhostXz.sendMessage(m.chat, {
                text: body.replace(/@everyone/i, '@' + m.chat),
                contextInfo: {
                    mentionedJid: (await GhostXz.groupMetadata(m.chat)).participants.map(v => v.id),
                    groupMentions: [{
                        groupSubject: "everyone",
                        groupJid: m.chat
                    }]
                }
            })
        }
    }
    }

const totalFitur = () =>{
            var mytext = fs.readFileSync("./message.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }

//functions 
async function toIDR(x) {
x = x.toString()
var pattern = /(-?\d+)(\d{3})/
while (pattern.test(x))
x = x.replace(pattern, "$1.$2")
return x
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomFile(ext) {
    return `${Math.floor(Math.random() * 10000)}${ext}`;
}

async function makeStickerFromUrl(imageUrl, GhostXz, m) {
    try {
        let buffer;
        if (imageUrl.startsWith("data:")) {
            const base64Data = imageUrl.split(",")[1];
            buffer = Buffer.from(base64Data, 'base64');
        } else {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, "binary");
        }
        
        const webpBuffer = await sharp(buffer)
            .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
            .webp({ quality: 70 })
            .toBuffer();
        
        const penis = await addExif(webpBuffer, global.packname, global.author)

        const fileName = getRandomFile(".webp");
        fs.writeFileSync(fileName, webpBuffer);

        await GhostXz.sendMessage(m.chat, {
            sticker: penis,
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: `Ghost - X`,
                    body: `Ghost - X Stil Learning `,
                    mediaType: 3,
                    renderLargerThumbnail: false,
                    thumbnailUrl: `https://files.catbox.moe/v1ulp7.jpg`,
                    sourceUrl: `-`
                }
            }
        }, { quoted: m });

        fs.unlinkSync(fileName);
    } catch (error) {
        console.error("Error creating sticker:", error);
        reply('Terjadi kesalahan saat membuat stiker. Coba lagi nanti.');
    }
}

async function reply(teks) {
    return GhostXz.sendMessage(m?.chat,
        {
          text: teks,
          mentions: await GhostXz.ments(teks),
          contextInfo: {
            mentionedJid: await GhostXz.ments(teks),
            externalAdReply: {
              showAdAttribution: true,
              title: `Hi ${pushname}`,
              body: `Runtime: ${runtime(process.uptime()).trim()}`,
              previewType: "PHOTO",
              thumbnailUrl: "https://files.catbox.moe/b7s07h.jpg",
              sourceUrl: "-",
            },
          },
        },
        { quoted: m },
      );
}


//================== [ DATABASE ] ==================//
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
 if (!('status_deposit' in user)) user.status_deposit = false
 if (!('premium' in user)) user.premium = false
} else global.db.data.users[m.sender] = {
status_deposit: false, 
premium: false,
}

 let chats = global.db.data.chats[m.chat]
 if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
 if (chats) {
 if (!('welcome' in chat)) chat.welcome = false
 if (!('antilinkgc' in chat)) chat.antilinkgc = false
 if (!('isBanned' in chat)) chat.isBanned = false
 } else global.db.data.chats[m.chat] = {
 welcome: false,
 antilinkgc: false,
 isBanned: false,
}

let setting = global.db.data.settings[botNumber]
if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
if (setting) {
 if (!('autoread' in setting)) setting.autoread = false
if (!("public" in settings)) settings.public = true
} else global.db.data.settings[botNumber] = {
 autoread: false,
 public: true,
}
} catch (err) {
}

if (global.db.data.chats[m.chat].antilinkgc) {
            if (budy.match(`chat.whatsapp.com`)) {
               bvl = `\`\`\`「 GC Link Detected 」\`\`\`\n\nAdmin has sent a gc link, admin is free to send any link😇`
if (isAdmins) return reply(bvl)
if (m.key.fromMe) return reply(bvl)
if (isCreator) return reply(bvl)
               await GhostXz.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			GhostXz.sendMessage(from, {text:`\`\`\`「 GC Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} has sent a link and successfully deleted`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
            }
        }

if (m.message) {
    console.log(chalk.green.bgHex("#e74c3c").bold(`\n💫 ${ucapanWaktu} 💫`))
    console.log(chalk.green.bgHex("#e74c3c").bold(`✉️ Pesan Baru`))
    console.log(chalk.black.bgHex("#00FF00")(`📅 Tanggal: ${new Date().toLocaleString()} \n💬 Pesan: ${m.body || m.mtype} \n🗣️ Pengirim: ${m.pushName} \n🔢 JID: ${m.sender}`))
    if (m.isGroup) {
        console.log(chalk.black.bgHex("#00FF00")(`🏷️ Grup: ${groupName}`))
        console.log(chalk.black.bgHex("#00FF00")(`🧷 GroupJid: ${m.chat}`))
    }
    //await sleep(1000)
    //await console.log(JSON.stringify(m.message))
}

switch(command) {
//=================================================//
case 'menu':{
const muptime = runtime(process.uptime()).trim()
const tek = `
▢ Status: ${isCreator ? "Owner" : "User"}
▢ Owner Name: ${ownername}
▢ Bot Name: ${botname}
▢ Version Bot: ${version}
▢ Total Fitur: ${totalFitur()}

— Owner
 ${Hiasan}public
 ${Hiasan}self
 ${Hiasan}upch audio
 ${Hiasan}setpp
 ${Hiasan}restart

— Main
 ${Hiasan}ping
 ${Hiasan}tqto

— Tools
 ${Hiasan}get
 ${Hiasan}gitclone
 ${Hiasan}cekidch
 ${Hiasan}ocr

— Search
 ${Hiasan}play
 ${Hiasan}tiktoks
 ${Hiasan}halodoc
 ${Hiasan}chord
 
— Download 
 ${Hiasan}tiktok
 ${Hiasan}mediafire
 ${Hiasan}ytmp3
 ${Hiasan}ytmp4
 ${Hiasan}igdl
 ${Hiasan}fbdl

— Convert 
 ${Hiasan}tourl
 ${Hiasan}brat
 ${Hiasan}sticker 
 ${Hiasan}bratvid
 ${Hiasan}toenchant
 ${Hiasan}toimg
 ${Hiasan}tinyurl

— Group 
 ${Hiasan}kick
 ${Hiasan}tagall
 ${Hiasan}opengc
 ${Hiasan}closegc
 ${Hiasan}antilinkgc
 ${Hiasan}welcome
 ${Hiasan}hidetag
 ${Hiasan}add
 ${Hiasan}promote
 ${Hiasan}demote
 ${Hiasan}resetlinkgc
 
— Ai
 ${Hiasan}gemini
 
— Store 
 ${Hiasan}buypanel
 ${Hiasan}batalbeli
 ${Hiasan}done
`
GhostXz.sendMessage(m?.chat,{text:tek,mentions:[m?.sender]},{quoted:qtext })
}
break

case 'public': {
if (!isCreator) return reply(mess.owner) 
GhostXz.public = true
reply('_Sukse Change To Public_')
}
break

case 'self': {
if (!isCreator) return reply(mess.owner) 
GhostXz.public = false
reply('_Sukses Change To Self_')
}
break

case'tagall':{
        if (!isAdmins) return reply(mess.admin);
        if (!m.isGroup) return reply(mess.group);

        const textMessage = args.join(" ") || "kosong";
        let teks = `pesan tagall :\n> *${textMessage}*\n\n`;

        const groupMetadata = await GhostXz.groupMetadata(m.chat);
        const participants = groupMetadata.participants;

        for (let mem of participants) {
            teks += `@${mem.id.split("@")[0]}\n`;
        }

        GhostXz.sendMessage(m.chat, {
            text: teks,
            mentions: participants.map((a) => a.id)
        }, { quoted: m });
      }
      break

case 'gitclone': {
if (!text) return reply("https://github.com/kiuur/case")
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    GhostXz.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await reply(`Error! Repositori Tidak Ditemukan`)
}}
break

case 'chord':
case 'cr': {
  if(!text) return m.reply(`masukan query`);
  let anu = `https://api.diioffc.web.id/api/search/chord?query=${encodeURIComponent(text)}`;
  const res = await fetch(anu)
  const response = await res.json();
  m.reply(`Url: ${response.result.url}\nArtis: ${response.result.artist}\nArtisUrl: ${response.result.artistUrl}\nJudul: ${response.result.title}\nChord: ${response.result.chord}`), { quoted: m };
}
break

case 'tiktoksearch':
case 'tiktoks': {
if (!text) return m.reply(`mau cari apa`)
m.reply('Proses 🗿')
await fetch(`https://api.diioffc.web.id/api/search/tiktok?query=${text}`).then(async (res) => {
let response = await res.json()
let result = response.result[Math.floor(Math.random() * response.result.length)]
GhostXz.sendMessage(m.chat, { video: { url: result.media.no_watermark }, mimetype: 'video/mp4', caption: result.title }, { quoted : m })
setTimeout(() => {
GhostXz.sendMessage(m.chat, { audio: { url: result.media.audio }, mimetype: "audio/mpeg", contextInfo: { externalAdReply: { thumbnailUrl: result.thumbnail, title: result.music.title, body: result.music.author, sourceUrl: null, renderLargerThumbnail: true, mediaType: 1}}}, { quoted: m })
}, 3000)
}).catch(err => m.reply('Error 🗿'))
}
break

case 'sticker':
case 's':
case 'stiker': {
    if (!quoted) return reply(`reply image/video dengan caption ${prefix + command}`);
    try {
        if (/image/.test(mime)) {
            const media = await quoted.download();
            const imageUrl = `data:${mime};base64,${media.toString('base64')}`;
            await makeStickerFromUrl(imageUrl, GhostXz, m);
        } else if (/video/.test(mime)) {
            if ((quoted?.msg || quoted)?.seconds > 10) return reply('Durasi video maksimal 10 detik!')
                const media = await quoted.download();
                const videoUrl = `data:${mime};base64,${media.toString('base64')}`;
                await makeStickerFromUrl(videoUrl, GhostXz, m);
            } else {
                return reply('Kirim gambar/video dengan caption .s (video durasi 1-10 detik)');
            }
        } catch (error) {
            console.error(error);
            return reply('Terjadi kesalahan saat memproses media. Coba lagi.');
        }
    }
    break;

case 'gemini': {
   const { GoogleGenerativeAI } = require("@google/generative-ai");
    if (!text) return reply(`Contoh:\n${prefix + command} Halo?`);
const apikeynyah = "AIzaSyB3Q74etnADQ_qSX3OJtzTnteGh-fd4df8"
const genAI = new GoogleGenerativeAI(apikeynyah);
const model = genAI.getGenerativeModel({ model: "models/gemini-1.5-pro" });
const prompt = `${text}`;
const result = await model.generateContent(prompt);  
  reply(`[ GEMINI - AI ]\n\n${result.response.text()}`)
}
break

case 'halodoc': {
if (!text) return reply(`tanyakan penyakit apa contoh .demam`)
m.reply(mess.proses)
await fetch(`https://api.diioffc.web.id/api/search/halodoc?query=${text}`).then(async (res) => {
let response = await res.json()
let teks = '*🔎 Hasil Pencarian HALODOC*\n\n'
for (let i of response.result) {
teks += `*◦ Judul :* ${i.judul}\n`
teks += `*◦ Deskripsi :* ${i.deskripsi}\n`
teks += `*◦ Link Url :* ${i.tautan}\n\n`
}
m.reply(teks)
}).catch(err => m.reply('Error 🗿'))
}
break

case 'resetlinkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.botAdmin)
await GhostXz.groupRevokeInvite(m.chat)
reply("Berhasil mereset link grup ✅")
}
break

case 'ocr': {
if (!quoted) return reply(`reply image`)
if (!/image/.test(mime) && !/webp/.test(mime)) return reply(`Reply Image`)
let img = await quoted.download()
try {
let anu = await (await Tesseract.recognize(img, 'eng')).data.text
reply(`*Result :*\n${anu}`)
} catch (e) {
console.log(e)
m.reply('failed to read text.')
}
}
break

case'ping':
case'info':{ 
const start = performance.now();
const cpus = os.cpus();
const uptimeSeconds = os.uptime();
const muptime = runtime(process.uptime()).trim()
const uptimeDays = Math.floor(uptimeSeconds / 86400);
const uptimeHours = Math.floor((uptimeSeconds % 86400) / 3600);
const uptimeMinutes = Math.floor((uptimeSeconds % 3600) / 60);
const uptimeSecs = Math.floor(uptimeSeconds % 60);
const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;
const formattedUsedMem = formatSize(usedMem);
const formattedTotalMem = formatSize(totalMem);
const loadAverage = os.loadavg().map(avg => avg.toFixed(2)).join(", ");
const speed = (performance.now() - start).toFixed(3);

const serverInfo = `Server Information:\n
- CPU Cores: ${cpus.length}
- CPU Model: ${cpus[0].model}
- Platform: ${os.platform()}
- Architecture: ${os.arch()}
- Uptime: ${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m ${uptimeSecs}s
- RAM: ${formattedUsedMem} / ${formattedTotalMem}
- Load Average (1, 5, 15 min): ${loadAverage}
- Response Time: ${speed} seconds
- Runtime: ${muptime}
- Type: case 
`.trim();

await reply(serverInfo)
}
break

case 'tinyurl': {
if (!text) return m.reply(`Kasih Link nya contoh.tinyurl https://ghostxdzz.web.id`)
reply(mess.proses)
await fetch(`https://api.diioffc.web.id/api/tools/tinyurl?url=${text}`).then(async (res) => {
let response = await res.json()
m.reply(`*◦ Link :* ${response.result.link}`)
}).catch(err => m.reply('Error 🗿'))
}
break

case 'setpp': {
      if (!isCreator) return reply(mess.owner);
      if (!quoted) return reply(`mana gambarnya? reply gambar dengan caption ${prefix + command}`);
      try {
          let mime = quoted.message?.imageMessage?.mimetype || quoted.mimetype || "";
          if (!mime.startsWith("image/")) return reply(`FOTO njrr`);
          if (/webp/.test(mime)) return reply(`sini muka lu ku tempelin stiker anjg!`);
          let media = await GhostXz.downloadMediaMessage(quoted);
          if (!media) return reply(`gagal mengunduh gambar, coba lagi nanti!`);
          await GhostXz.updateProfilePicture(botNumber, media);
          reply(`horee, foto profil berhasil di perbarui`);
      } catch (error) {
          console.error(error);
          reply(`aduhh, ada error nih : ${error}`);
      }
  }
  break 

case 'restart':
if (!isCreator) return reply(mess.owner)
reply(`Restarting Ghost - X`)
await sleep(3000)
process.exit()
break

case 'toimg': {
 if (!quoted) reply ('m?.reply Image')
if (!/webp/.test(mime)) reply (`Balas sticker dengan caption *${prefix + command}*`)
let media = await GhostXz.downloadAndSaveMediaMessage(quoted)
let ran = 'jjsjsnsu.png'
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) reply (err)
let buffer = fs.readFileSync(ran)
GhostXz.sendMessage(m.chat, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}
break

case 'tqto': {
  let text = `Hai @${m.sender.split('@')[0]}\n\nTerima kasih kepada orang-orang berikut yang telah membantu dalam pengembangan script ini:\n\n`;
  text += `• Ghost - X (Pengembang)\n`;
  text += `• KyuuRzy (Dukungan & Penyemangat & Sahabat)\n`;
  text += `• DiiOffc (Dukungan & Sahabat)\n`;
  text += `Terima kasih banyak!`;

  GhostXz.sendMessage(m.chat, {
    text,
    contextInfo: {
      mentionedJid: [m.sender],
      isForwarded: true,
      externalAdReply: {
        title: `Thanks To - Participate`,
        body: `Thanks For`,
        thumbnailUrl: `https://files.catbox.moe/6pausp.jpg`,
        sourceUrl: `-`,
        mediaType: 1,
        showAdAttribution: true,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
}
break;

case 'done': {
if (!isCreator) return reply(mess.owner)
if (!q) return reply("jasa install panel")
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linksaluran}

*Marketplace :*
-`
await GhostXz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${ownername}`, 
thumbnailUrl: 'https://img0.pixhost.to/images/919/557813345_ghostxzdzz.jpg', 
sourceUrl: linksaluran,
}}}, {quoted: null})
}
break

case 'upch': {
    if (args[0] === "audio") {
        if (!isCreator) return reply(mess.owner);
        GhostXz.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        await sleep(2000);
        GhostXz.sendMessage(m.chat, { react: { text: '⌛', key: m.key } });
        GhostXz.sendMessage(`${global.idch}`, {
            audio: await quoted.download(),
            mimetype: 'audio/mp4',
            ptt: true
        });
        await sleep(2000);
        GhostXz.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    }
}
break;

case 'tourl': {
if (!/image/.test(mime)) return reply("dengan kirim/reply foto")
let media = await GhostXz.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'GhostXzdzz.png');

let teks = directLink.toString()
await GhostXz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

case 'cekidch': case 'idch': {
if (!text) return reply("linkchnya")
if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await GhostXz.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return reply(teks)
}
break

case 'toenchant': {
    try {
      const charMap = {
        a: "ᔑ",
        b: "ʖ",
        c: "ᓵ",
        d: "↸",
        e: "ᒷ",
        f: "⎓",
        g: "⊣",
        h: "⍑",
        i: "╎",
        j: "⋮",
        k: "ꖌ",
        l: "ꖎ",
        m: "ᒲ",
        n: "リ",
        o: "𝙹",
        p: "!¡",
        q: "ᑑ",
        r: "∷",
        s: "ᓭ",
        t: "ℸ ̣",
        u: "⚍",
        v: "⍊",
        w: "∴",
        x: "̇/",
        y: "||",
        z: "⨅"
      }
      if (!text) return reply("Harap masukkan teks yang ingin convert!")
      const convertToEnchant = async (text) => {
        return new Promise((resolve) => {
          const result = text
            .toLowerCase()
            .split("")
            .map((char) => charMap[char] || char)
            .join("")
          resolve(result)
        })
      }
      const loli = await convertToEnchant(text)
      reply(`*Input:*\n${text}\n\n*Hasil convert:*\n${loli}`)
    } catch (err) {
      return err
    }
  }
 break

case 'opengc':
      case 'buka': {
          if (!m.isGroup) return reply(mess.group)
          if (!isAdmins && !isCreator) return reply(mess.admin)
          if (!isBotAdmins) return m.tolak(mess.botadmin)
          GhostXz.groupSettingUpdate(m.chat, 'not_announcement')
          reply(`sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini`)
      }
      break
                
      case 'closegc':
      case 'tutup': {
          if (!m.isGroup) return reply(mess.group)
          if (!isAdmins && !isCreator) return reply(mess.admin)
          if (!isBotAdmins) return m.tolak(mess.botadmin)
          GhostXz.groupSettingUpdate(m.chat, 'announcement')
          reply(`sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini`)
      }
      break

case 'bratvid': {
  if (!text) return m.reply(`Contoh: ${prefix+command} hai`)
  if (text.length > 250) return m.reply(`Karakter terbatas, max 250!`)

  const words = text.split(" ")
  const tempDir = path.join(process.cwd(), 'lib')
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)
  const framePaths = []

  try {
    for (let i = 0; i < words.length; i++) {
      const currentText = words.slice(0, i + 1).join(" ")

      const res = await axios.get(
        `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(currentText)}`,
        { responseType: "arraybuffer" }
      ).catch((e) => e.response)

      const framePath = path.join(tempDir, `frame${i}.mp4`)
      fs.writeFileSync(framePath, res.data)
      framePaths.push(framePath)
    }

    const fileListPath = path.join(tempDir, "filelist.txt")
    let fileListContent = ""

    for (let i = 0; i < framePaths.length; i++) {
      fileListContent += `file '${framePaths[i]}'\n`
      fileListContent += `duration 0.7\n`
    }

    fileListContent += `file '${framePaths[framePaths.length - 1]}'\n`
    fileListContent += `duration 2\n`

    fs.writeFileSync(fileListPath, fileListContent)
    const outputVideoPath = path.join(tempDir, "output.mp4")
    execSync(
      `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${outputVideoPath}`
    )

    await GhostXz.sendImageAsSticker(m.chat, outputVideoPath, m, {
      packname: '',
      author: `Ghost - X`
    })

    framePaths.forEach((frame) => {
      if (fs.existsSync(frame)) fs.unlinkSync(frame)
    })
    if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath)
    if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath)
  } catch (e) {
    console.error(e)
    m.reply('Terjadi kesalahan')
  }
}
break

case'brat':{
            if (!text) return reply(`mana text nya? contoh ${prefix + command} apanih cok`)
            const imageUrl = `https://brat.caliphdev.com/api/brat?text=${text}`;
            await makeStickerFromUrl(imageUrl, GhostXz, m);
        }
       break
       
       case 'welcome':
            case 'left': {
               if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return relply(mess.owner)
               if (args.length < 1) return reply('on/off?')
               if (args[0] === 'on') {
                  welcome = true
                  reply(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  welcome = false
                  reply(`${command} is disabled`)
               }
            }
            break
       
       case 'antilinkgc': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply('Khusus Owner')
               if (args.length < 1) return reply('on/off?')
               if (args[0] === 'on') {
                  global.db.data.chats[m.chat].antilinkgc = true
                  reply(`${command} is enabled`)
               } else if (args[0] === 'off') {
                  global.db.data.chats[m.chat].antilinkgc = false
                  reply(`${command} is disabled`)
               }
            }
            break
       

       case 'h':
  case 'hidetag': {
      if (!m.isGroup) return reply(mess.group)
      if (!isAdmins && !isCreator) return reply(mess.admin)
      if (m.quoted) {
          GhostXz.sendMessage(m.chat, {
              forward: m.quoted.fakeObj,
              mentions: participants.map(a => a.id)
          })
      }
      if (!m.quoted) {
          GhostXz.sendMessage(m.chat, {
              text: q ? q : '',
              mentions: participants.map(a => a.id)
          }, { quoted: m })
      }
  }
  break
  
  case 'play': {
if (!text) return reply("dj tiktok")
await GhostXz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await GhostXz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return reply("Error! Result Not Found")
}
await GhostXz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
  
  case 'mediafire': {
  if (!text) return reply("linknya")
  if (!text.includes("mediafire.com")) return reply("Link tautan tidak valid");

  try {
    const res = await mediafire(text);
    if (!res.link) return reply("Error! Result Not Found");

    await GhostXz.sendMessage(
      m.chat,
      {
        document: { url: res.link },
        fileName: res.judul,
        mimetype: "application/" + res.mime.toLowerCase(),
      },
      { quoted: m }
    );
  } catch (e) {
    reply("Error! Result Not Found");
  }
}
break;
  
  case 'fb': case 'fbdl': {
if (!text.includes("facebook.com")) return reply("Masukan link facebook!")
try {
  axios({ "method": "GET", "url": "https://mannoffc-x.hf.space/download/facebook", "params": { "url": text }}).then(_ => {
    GhostXz.sendMessage(m.chat, { video: { url: _.data.result.video }, caption: "Ini dia kak" }, { quoted: m })
  })
} catch ({ message }) {
  reply(message)
}
}
break
  
  case 'igdl':
    case 'ig': {
        if (!text) return reply(`mana link instagram-nya? contoh: ${prefix + command} https://www.instagram.com/reel/DB8BGCZRKAh/?igsh=eDk1ajRncDV6Mjdh`);
    
        let memek = await igdl(text);
    
        let respon = memek.data;
        if (respon && respon.length > 0) {
        
            let uniqueUrls = new Set(respon.map(item => item.url));
            try {
                for (let mediaUrl of uniqueUrls) {
                    const headResponse = await axios.head(mediaUrl);
                    const mimeType = headResponse.headers['content-type'];

                    const isImage = /image\/.*/.test(mimeType);
                    const isVideo = /video\/.*/.test(mimeType);

                    if (isImage) {
                        await GhostXz.sendMessage(m.chat, {
                            image: { url: mediaUrl },
                            caption: "berhasil mendownload gambar dari URL."
                        }, { quoted: m });
                    } else if (isVideo || mimeType === 'application/octet-stream') {
                        await GhostXz.sendMessage(m.chat, {
                            video: { url: mediaUrl },
                            caption: "berhasil mendownload video dari URL."
                        }, { quoted: m });
                    } else {
                        await GhostXz.sendMessage(m.chat, {
                            text: `tipe media tidak didukung: ${mimeType}`
                        }, { quoted: m });
                    }
                }
            } catch (error) {
                console.error('Error fetching media type:', error);
                reply(error)
            }
        } else {
            await GhostXz.sendMessage(m.chat, {
                text: "Tidak ditemukan media atau terjadi kesalahan saat mengambil media."
            }, { quoted: m });
        }
    }
    break;
  
  case 'ytmp4': {
if (!text) return reply("linknya")
if (!text.startsWith("https://")) return reply("Link Tautan Tidak Valid")
await GhostXz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await ytdl.ytmp4(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await GhostXz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return reply("Error! Result Not Found")
}
await GhostXz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
  
  case 'ytmp3': {
    if (!text) {
        return reply("Masukkan linknya!");
    }

    if (!text.startsWith("https://")) {
        return reply("Link tautan tidak valid!");
    }

    await GhostXz.sendMessage(m.chat, { react: { text: '🕖', key: m.key } });

    try {
        var anu = await ytdl.ytmp3(`${text}`);

        if (anu.status) {
            let urlMp3 = anu.download.url;
            await GhostXz.sendMessage(m.chat, { audio: { url: urlMp3 }, mimetype: "audio/mpeg" }, { quoted: m });
        } else {
            return reply("Error! Result not found.");
        }
    } catch (error) {
        console.error(error);
        return reply("Terjadi kesalahan saat memproses permintaan.");
    }

    await GhostXz.sendMessage(m.chat, { react: { text: '', key: m.key } });
}
break;
  
  case'tiktok':
      case'tt':{
        if (!text) return reply(`mana link tiktok nya? contoh ${prefix + command} https://`);
         let res = await tiktok(text);
         if (res && res.data && res.data.data) {
            let images = res.data.data.images || [];
            let play = res.data.data.play;
            let lagu = res.data.data.music

            const getMimeType = async (url) => {
                try {
                    const response = await axios.head(url);
                    return response.headers['content-type'];
                } catch (error) {
                    console.error(error);
                    return
                }
            };

            let mimeType = await getMimeType(play);
            
            if (mimeType && mimeType.startsWith('video/')) {
                await GhostXz.sendMessage(m.chat, {
                    video: { url: play },
                    caption: "Successfully downloaded video from TikTok"
                },{quoted:m});
            } else if (images.length > 0) {
                let totalImages = images.length;
                let estimatedTime = totalImages * 4;
                let message = `Estimasi waktu pengiriman gambar: ${estimatedTime} detik.`;
                await GhostXz.sendMessage(m.chat, { text: message },{quoted:m});

                const sendImageWithDelay = async (url, index) => {
                    let caption = `Gambar ke-${index + 1}`;
                    await GhostXz.sendMessage(m.chat, { image: { url }, caption: caption },{quoted:m});
                };
                await GhostXz.sendMessage(m.chat, { audio: { url: lagu }, mimetype: "audio/mpeg" },{quoted:m})

                for (let i = 0; i < images.length; i++) {
                    await sendImageWithDelay(images[i], i);
                    await new Promise(resolve => setTimeout(resolve, 4000));
                }
            } else {
                console.log('No valid video or images found.');
                await GhostXz.sendMessage(m.chat, {
                    text: "No media found or an error occurred while retrieving media."
                },{quoted:m});
            }
        } else {
            console.error('Error: Invalid response structure', res);
            await GhostXz.sendMessage(m.chat, {
                text: "No media found or an error occurred while retrieving media."
            },{quoted:m});
        }
      }
      break
  
case 'demote':
case 'promote': {
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.botAdmin)
if (!isCreator && !m.isAdmins) return reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await GhostXz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await GhostXz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return reply(example("@tag/6285###"))
}
}
break

case 'kick': case 'dor': {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !isAdmins) return reply(mess.admin)
if (!isBotAdmins) return reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await GhostXz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor tidak terdaftar di whatsapp")
const res = await GhostXz.groupParticipantsUpdate(m.chat, [input], 'remove')
await reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return reply("@tag/reply")
}
}
break

case 'get':
if (!/^https?:\/\//.test(text)) return reply(`'Awali *URL* dengan http:// atau https://`)
const ajg = await fetch(text);
if (ajg.headers.get('content-length') > 100 * 1024 * 1024 * 1024) {
throw `Content-Length: ${ajg.headers.get('content-length')}`;
}
const contentType = ajg.headers.get('content-type');
if (contentType.startsWith('image/')) {
return GhostXz.sendMessage(m.chat, { image: { url: text } }, 'imageMessage', text, m);
}
if (contentType.startsWith('video/')) {
return GhostXz.sendMessage(m.chat, { video: { url: text } }, 'videoMessage', text, m);
}
if (contentType.startsWith('audio/')) {
return GhostXz.sendMessage(m.chat, { audio: { url: text } }, 'audioMessage', text, m);
}
let alak = await ajg.buffer();
try {
alak = util.format(JSON.parse(alak + ''));
} catch (e) {
alak = alak + '';
} finally {
reply(alak.slice(0, 65536));
}
break          

case 'buypanel': {
if (m.isGroup) return reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (global.db.data.users[m.sender].status_deposit) return reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *乂 List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buypanel* 2gb
`
if (!text) return reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli" || cmd == "unlimited") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://api.simplebot.my.id/api/orkut/createpayment?apikey=${global.apiSimpelBot}&amount=${amount}&codeqr=${UrlQr}`)

const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await GhostXz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
global.db.data.users[m.sender].status_deposit = true
global.db.data.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (global.db.data.users[m.sender].status_deposit == true && global.db.data.users[m.sender].saweria && global.db.data.users[m.sender].saweria.amount) {
await GhostXz.sendMessage(global.db.data.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: global.db.data.users[m.sender].saweria.msg})
await GhostXz.sendMessage(global.db.data.users[m.sender].saweria.chat, { delete: global.db.data.users[m.sender].saweria.msg.key })
global.db.data.users[m.sender].status_deposit = false
await clearInterval(global.db.data.users[m.sender].saweria.exp)
delete global.db.data.users[m.sender].saweria
}
}, 300000)
}
}

await global.db.data.users[m.sender].saweria.exp()

while (global.db.data.users[m.sender].status_deposit == true && global.db.data.users[m.sender].saweria && global.db.data.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://api.simplebot.my.id/api/orkut/cekstatus?apikey=${global.apiSimpelBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (global.db.data.users[m.sender].saweria && req?.amount == global.db.data.users[m.sender].saweria.amount) {
global.db.data.users[m.sender].status_deposit = false
await clearInterval(global.db.data.users[m.sender].saweria.exp)
await GhostXz.sendMessage(global.db.data.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${global.db.data.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(global.db.data.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
`}, {quoted: global.db.data.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = global.db.data.users[m.sender].saweria.chat
var tekspanel = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}
* *Cpu :* ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}
* *Disk :* ${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await GhostXz.sendMessage(orang, {text: tekspanel}, {quoted: null})
await GhostXz.sendMessage(global.db.data.users[m.sender].saweria.chat, { delete: global.db.data.users[m.sender].saweria.msg.key })
delete global.db.data.users[m.sender].saweria
}
}

}
break

case 'batalbeli': {
if (m.isGroup) return
if (global.db.data.users[m.sender].status_deposit == false) return 
global.db.data.users[m.sender].status_deposit = false
if ('saweria' in global.db.data.users[m.sender]) {
await GhostXz.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: global.db.data.users[m.sender].saweria.msg})
await GhostXz.sendMessage(m.chat, { delete: global.db.data.users[m.sender].saweria.msg.key })
await clearInterval(global.db.data.users[m.sender].saweria.exp)
delete global.db.data.users[m.sender].saweria
} else {
await reply("Berhasil membatalkan pembelian ✅")
}
}
break

case 'add': {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !isAdmins) return reply(mess.admin)
if (!isBotAdmins) return reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await GhostXz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return reply("Nomor tidak terdaftar di whatsapp")
const res = await GhostXz.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return reply(JSON.stringify(res, null, 2))
}} else {
return reply("62838###")
}
}
break

default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m?.reply(bang)
}
try {
m?.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m?.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m?.reply(require('util').format(teks))
}
}

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))
}}

if (body.startsWith("nn")) {
if (!isCreator) return 
        if (!q) return reply('codenya mana kak')
        syntaxerror = require('syntax-error')
        _syntax = ''
        _text = args.join(' ')
        try {
          evalll = await eval(`;(async () => { return ${args.join(' ')} })()`)
          reply(require('util').format(evalll))
        } catch (e) {
          let err = await syntaxerror(_text, 'Execution Function', {
            allowReturnOutsideFunction: true,
            allowAwaitOutsideFunction: true
          })
          if (err) _syntax = '```' + err + '```\n\n'
          _return = e
          await reply(_syntax + require('util').format(_return))
        }
      }

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m?.reply(`${err}`)
if (stdout) return m?.reply(stdout)
})
}

if ((m?.mtype === 'groupInviteMessage' || m?.text.startsWith('Undangan untuk bergabung') || m?.text.startsWith('Invitation to join') || m?.text.startsWith('Buka tautan ini')) && !m?.isBaileys && !m?.isGroup) {
await GhostXz.sendMessage(m?.chat, {react: {text: `🤨`,key: m?.key,}})
let teks = 'group apa itu'
m?.reply(teks)
}

if (!m?.fromMe & !m?.isGroup) {
let user = global.db.data.users[m?.sender];
const cooldown = 21600000;
if (new Date() - user.pc < cooldown) return; 
let caption = `Hᴀʟᴏ @${m?.sender.split('@')[0]} ${ucapanWaktu}, ᴀᴅᴀ ᴀᴘᴀ ᴄʜᴀᴛ *Ghost - X Bot*, Jɪᴋᴀ ᴘᴇɴᴛɪɴɢ ᴛɪɴɢɢᴀʟᴋᴀɴ ᴄʜᴀᴛ ᴅᴀɴ *Sɪᴘᴜᴛᴢx* ᴀᴋᴀɴ ᴍᴇᴍʙᴀʟᴀꜱ ꜱᴇᴄᴇᴘᴀᴛ ᴍᴜɴɢᴋɪɴ.`.trim();
GhostXz.sendMessage(m?.chat,{text:caption,mentions:[m?.sender]},{quoted:m})
user.pc = new Date() * 1;
}
}
} catch (err) {
console.log(util.format(err))
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(color(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
