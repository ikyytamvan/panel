const fs = require('fs')
const { color } = require('./lib/myfunc')

global.rowner = [["6281228599963", "Ghost - X", true], ["-", "Ghost - X Bot", true]];
global.ownername = "Ghost - X"
global.botname = "Ghost - X Bot"
global.version = "0.0.1"
global.packname = "Di Buat Oleh"
global.author = "Ghost - X"
global.idch = "120363313702511471@newsletter"
global.urldb = ''; // kosongin aja

global.linksaluran = "https://whatsapp.com/channel/0029VadfVP5ElagswfEltW0L"

global.apiSimpelBot = "skyzo77"
global.merchantIdOrderKuota = "-"
global.apiOrderKuota = "-"
global.qrisOrderKuota = "-"

global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "https://"
global.apikey = ""
global.capikey = ""

//Symbol
global.Hiasan = "๑ ."

global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

global.status = true
global.welcome = true

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(color(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
